﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantAss9feb.Models
{
    public enum Cusine
    {
        None,
        Italian,
        French,
        Indian

    }
    public class Restaurant
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Cusine Cusine{ get; set; }
    }
}