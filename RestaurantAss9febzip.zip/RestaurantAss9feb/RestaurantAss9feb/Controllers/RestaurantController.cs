﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RestaurantAss9feb.Models;

namespace RestaurantAss9feb.Controllers
{
    public class RestaurantController : Controller
    {
        // GET: Restaurant
        public ActionResult Index()
        {
            List<Restaurant> restaurant = new List<Restaurant>
            { 
                new Restaurant{Id=1,Name="PlainPizza",Cusine=Cusine.French },
                new Restaurant{Id=2,Name="Andhra Restaurant",Cusine=Cusine.Indian },
                new Restaurant{Id=3,Name="KFC",Cusine=Cusine.Italian }
            };

            return View(restaurant);
        }
        public ActionResult Details(int id)
        {
            List<Restaurant> restaurant = new List<Restaurant>
            {
                new Restaurant{Id=1,Name="PlainPizza",Cusine=Cusine.French },
                new Restaurant{Id=2,Name="Andhra Restaurant",Cusine=Cusine.Indian },
                new Restaurant{Id=3,Name="KFC",Cusine=Cusine.Italian }
            };
            Restaurant res1 = null;
            foreach (var item in restaurant)
            {
                if (item.Id == id)
                {
                    res1 = item;
                }
            }

            return View(res1);
        }
        public ActionResult Image()
        {
            return View();
        }

    }
}